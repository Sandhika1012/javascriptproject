import { useState, useEffect } from "react";
import { getProducts, Product } from "@/lib/storage";
import { AdminPanel } from "@/components/AdminPanel";
import { Button } from "@/components/ui/button";
import { ShoppingBag, Shield, LogOut } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

const Admin = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const navigate = useNavigate();
  const { logout } = useAuth();

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = () => {
    setProducts(getProducts());
  };

  const handleLogout = () => {
    logout();
    navigate("/admin-login");
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border shadow-card">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" />
            <h1 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent">
              Admin Panel
            </h1>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              className="border-primary hover:bg-secondary"
              onClick={() => navigate("/")}
            >
              <ShoppingBag className="mr-2 h-4 w-4" />
              View Shop
            </Button>
            <Button
              variant="outline"
              className="border-destructive hover:bg-destructive hover:text-destructive-foreground"
              onClick={handleLogout}
            >
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <AdminPanel products={products} onUpdate={loadProducts} />
      </main>
    </div>
  );
};

export default Admin;
