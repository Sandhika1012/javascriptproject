import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ShoppingBag, Shield, Truck, CalendarDays, CreditCard } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { SupercoinButton } from "@/components/SupercoinButton";

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      {/* Header with Supercoin */}
      <div className="absolute top-4 right-4 z-50">
        <SupercoinButton />
      </div>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-glow opacity-50" />
        <div className="container mx-auto px-4 py-24 relative">
          <div className="max-w-4xl mx-auto text-center animate-fade-in">
            <div className="inline-flex items-center gap-2 bg-secondary/50 px-4 py-2 rounded-full mb-6 backdrop-blur">
              <ShoppingBag className="h-4 w-4 text-primary animate-glow-pulse" />
              <span className="text-sm font-semibold text-foreground">AI-Powered E-Commerce</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold mb-6 text-foreground">
              Welcome to
              <span className="block bg-gradient-primary bg-clip-text text-transparent mt-2">
                E-Commerce
              </span>
            </h1>
            
            <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
              Experience the future of online shopping with our intelligent product catalog.
              Smart search, dynamic filtering, and seamless cart management.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-gradient-primary hover:opacity-90 text-lg px-8 shadow-glow"
                onClick={() => navigate("/shop")}
              >
                <ShoppingBag className="mr-2 h-5 w-5" />
                Start Shopping
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-primary hover:bg-secondary text-lg px-8"
                onClick={() => navigate("/admin")}
              >
                <Shield className="mr-2 h-5 w-5" />
                Admin Panel
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card 
            className="bg-card border-border shadow-card hover:shadow-glow transition-all duration-300 cursor-pointer"
            onClick={() => navigate("/events")}
          >
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-gradient-primary rounded-lg flex items-center justify-center mx-auto mb-4">
                <CalendarDays className="h-6 w-6 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">Upcoming Events</h3>
              <p className="text-muted-foreground">
                Stay updated with exclusive product launches and flash sales
              </p>
            </CardContent>
          </Card>

          <Card 
            className="bg-card border-border shadow-card hover:shadow-glow transition-all duration-300 cursor-pointer"
            onClick={() => navigate("/delivery-track")}
          >
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-gradient-primary rounded-lg flex items-center justify-center mx-auto mb-4">
                <Truck className="h-6 w-6 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">Delivery Track</h3>
              <p className="text-muted-foreground">
                Track your orders in real-time through our supply chain
              </p>
            </CardContent>
          </Card>

          <Card 
            className="bg-card border-border shadow-card hover:shadow-glow transition-all duration-300 cursor-pointer"
            onClick={() => navigate("/payment-options")}
          >
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-gradient-primary rounded-lg flex items-center justify-center mx-auto mb-4">
                <CreditCard className="h-6 w-6 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">Payment Options</h3>
              <p className="text-muted-foreground">
                Multiple secure payment methods including crypto and digital wallets
              </p>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Index;
