import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CreditCard, Smartphone, Building2, Bitcoin, Wallet, QrCode } from "lucide-react";
import { useNavigate } from "react-router-dom";

const PaymentOptions = () => {
  const navigate = useNavigate();

  const paymentMethods = [
    {
      id: 1,
      name: "Google Pay",
      description: "Quick and secure payment via Google Pay",
      icon: Smartphone,
      badge: "Popular",
      features: ["Instant transfer", "UPI based", "No fees"],
    },
    {
      id: 2,
      name: "Bank Transfer",
      description: "Direct transfer from your bank account",
      icon: Building2,
      badge: "Secure",
      features: ["NEFT/RTGS/IMPS", "1-2 hours", "Bank verified"],
    },
    {
      id: 3,
      name: "Credit/Debit Card",
      description: "Pay using Visa, Mastercard, or Amex",
      icon: CreditCard,
      badge: "Fast",
      features: ["Instant payment", "EMI available", "Secure 3D"],
    },
    {
      id: 4,
      name: "Cryptocurrency",
      description: "Bitcoin, Ethereum, and other cryptocurrencies",
      icon: Bitcoin,
      badge: "Crypto",
      features: ["BTC, ETH, USDT", "Blockchain secure", "Global"],
    },
    {
      id: 5,
      name: "Digital Wallets",
      description: "PayPal, Paytm, PhonePe, and more",
      icon: Wallet,
      badge: "Flexible",
      features: ["Multiple wallets", "Cashback offers", "Instant"],
    },
    {
      id: 6,
      name: "UPI/QR Code",
      description: "Scan and pay via any UPI app",
      icon: QrCode,
      badge: "Easy",
      features: ["Any UPI app", "Instant", "No charges"],
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-12">
        <Button
          variant="outline"
          onClick={() => navigate("/")}
          className="mb-6"
        >
          ← Back to Home
        </Button>

        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Choose Your Payment Method
            </h1>
            <p className="text-xl text-muted-foreground">
              Multiple secure payment options for your convenience
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {paymentMethods.map((method) => {
              const Icon = method.icon;
              return (
                <Card
                  key={method.id}
                  className="bg-card border-border shadow-card hover:shadow-glow transition-all duration-300 hover:scale-105 cursor-pointer"
                >
                  <CardHeader>
                    <div className="flex items-start justify-between mb-2">
                      <div className="w-14 h-14 bg-gradient-primary rounded-lg flex items-center justify-center">
                        <Icon className="h-7 w-7 text-primary-foreground" />
                      </div>
                      <Badge className="bg-secondary text-secondary-foreground">
                        {method.badge}
                      </Badge>
                    </div>
                    <CardTitle className="text-xl text-foreground">
                      {method.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4">
                      {method.description}
                    </p>
                    <div className="space-y-2 mb-6">
                      {method.features.map((feature, idx) => (
                        <div
                          key={idx}
                          className="flex items-center text-sm text-muted-foreground"
                        >
                          <div className="w-1.5 h-1.5 bg-primary rounded-full mr-2" />
                          {feature}
                        </div>
                      ))}
                    </div>
                    <Button className="w-full bg-gradient-primary hover:opacity-90">
                      Select Payment
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <Card className="bg-card border-border shadow-card mt-12">
            <CardContent className="p-8">
              <div className="text-center">
                <h3 className="text-2xl font-semibold text-foreground mb-3">
                  Secure Payment Processing
                </h3>
                <p className="text-muted-foreground mb-6">
                  All transactions are encrypted and secured with industry-standard
                  security protocols. Your payment information is safe with us.
                </p>
                <div className="flex flex-wrap justify-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full" />
                    256-bit SSL Encryption
                  </span>
                  <span className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full" />
                    PCI DSS Compliant
                  </span>
                  <span className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full" />
                    2FA Authentication
                  </span>
                  <span className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full" />
                    24/7 Fraud Monitoring
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default PaymentOptions;
