import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Package, Truck, CheckCircle, MapPin } from "lucide-react";
import { useNavigate } from "react-router-dom";

const DeliveryTrack = () => {
  const navigate = useNavigate();

  const deliveryStages = [
    {
      id: 1,
      status: "Completed",
      title: "Order Placed",
      description: "Your order has been confirmed",
      location: "Mumbai, India",
      date: "Dec 20, 2025 - 10:30 AM",
      icon: CheckCircle,
    },
    {
      id: 2,
      status: "Completed",
      title: "Processing",
      description: "Order is being prepared for shipment",
      location: "Warehouse - Delhi",
      date: "Dec 21, 2025 - 2:15 PM",
      icon: Package,
    },
    {
      id: 3,
      status: "In Progress",
      title: "In Transit",
      description: "Package is on the way",
      location: "Regional Hub - Bangalore",
      date: "Dec 22, 2025 - 8:45 AM",
      icon: Truck,
    },
    {
      id: 4,
      status: "Pending",
      title: "Out for Delivery",
      description: "Package will arrive soon",
      location: "Local Facility - Your City",
      date: "Expected: Dec 23, 2025",
      icon: MapPin,
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-12">
        <Button
          variant="outline"
          onClick={() => navigate("/")}
          className="mb-6"
        >
          ← Back to Home
        </Button>

        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-foreground mb-2">
            Track Your Delivery
          </h1>
          <p className="text-muted-foreground mb-8">
            Real-time tracking through our supply chain network
          </p>

          <Card className="bg-card border-border shadow-card mb-8">
            <CardHeader>
              <CardTitle className="text-foreground">Order #EC2025-12345</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Estimated Delivery</p>
                  <p className="font-semibold text-foreground">Dec 23, 2025</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Carrier</p>
                  <p className="font-semibold text-foreground">Express Logistics</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Tracking ID</p>
                  <p className="font-semibold text-foreground">TRACK789456123</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-4">
            {deliveryStages.map((stage, index) => {
              const Icon = stage.icon;
              return (
                <Card
                  key={stage.id}
                  className={`bg-card border-border shadow-card transition-all duration-300 ${
                    stage.status === "In Progress"
                      ? "border-primary shadow-glow"
                      : ""
                  }`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div
                        className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${
                          stage.status === "Completed"
                            ? "bg-primary/20"
                            : stage.status === "In Progress"
                            ? "bg-gradient-primary"
                            : "bg-muted"
                        }`}
                      >
                        <Icon
                          className={`h-6 w-6 ${
                            stage.status === "Completed"
                              ? "text-primary"
                              : stage.status === "In Progress"
                              ? "text-primary-foreground"
                              : "text-muted-foreground"
                          }`}
                        />
                      </div>

                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="text-lg font-semibold text-foreground">
                            {stage.title}
                          </h3>
                          <Badge
                            variant={
                              stage.status === "Completed"
                                ? "default"
                                : stage.status === "In Progress"
                                ? "default"
                                : "secondary"
                            }
                            className={
                              stage.status === "In Progress"
                                ? "bg-gradient-primary"
                                : ""
                            }
                          >
                            {stage.status}
                          </Badge>
                        </div>
                        <p className="text-muted-foreground mb-2">
                          {stage.description}
                        </p>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <MapPin className="h-4 w-4" />
                            {stage.location}
                          </span>
                          <span>{stage.date}</span>
                        </div>
                      </div>
                    </div>

                    {index < deliveryStages.length - 1 && (
                      <div
                        className={`ml-6 mt-4 h-8 w-0.5 ${
                          stage.status === "Completed"
                            ? "bg-primary"
                            : "bg-border"
                        }`}
                      />
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeliveryTrack;
