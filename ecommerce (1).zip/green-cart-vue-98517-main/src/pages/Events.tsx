import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CalendarDays, Gift, Smartphone, Home as HomeIcon, Laptop, Watch, Headphones, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Events = () => {
  const navigate = useNavigate();

  const christmasOffers = [
    {
      id: 1,
      name: "iPhone 15 Pro Max",
      category: "Mobile",
      originalPrice: 1299,
      offerPrice: 999,
      discount: 23,
      icon: Smartphone,
      stock: 50
    },
    {
      id: 2,
      name: "Samsung Galaxy S24 Ultra",
      category: "Mobile",
      originalPrice: 1199,
      offerPrice: 899,
      discount: 25,
      icon: Smartphone,
      stock: 45
    },
    {
      id: 3,
      name: "MacBook Pro M3",
      category: "Laptop",
      originalPrice: 2499,
      offerPrice: 1999,
      discount: 20,
      icon: Laptop,
      stock: 30
    },
    {
      id: 4,
      name: "Apple Watch Series 9",
      category: "Wearable",
      originalPrice: 499,
      offerPrice: 349,
      discount: 30,
      icon: Watch,
      stock: 60
    },
    {
      id: 5,
      name: "Sony WH-1000XM5",
      category: "Audio",
      originalPrice: 399,
      offerPrice: 279,
      discount: 30,
      icon: Headphones,
      stock: 75
    },
    {
      id: 6,
      name: "Google Pixel 8 Pro",
      category: "Mobile",
      originalPrice: 999,
      offerPrice: 699,
      discount: 30,
      icon: Smartphone,
      stock: 40
    }
  ];

  const newYearOffers = [
    {
      id: 7,
      name: "OnePlus 12",
      category: "Mobile",
      originalPrice: 899,
      offerPrice: 649,
      discount: 28,
      icon: Smartphone,
      stock: 55
    },
    {
      id: 8,
      name: "iPad Pro 12.9",
      category: "Tablet",
      originalPrice: 1299,
      offerPrice: 999,
      discount: 23,
      icon: Laptop,
      stock: 35
    },
    {
      id: 9,
      name: "Nothing Phone 2",
      category: "Mobile",
      originalPrice: 699,
      offerPrice: 499,
      discount: 29,
      icon: Smartphone,
      stock: 50
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={() => navigate("/")}
              className="gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>
            <Button onClick={() => navigate("/shop")} className="bg-gradient-primary">
              Browse Shop
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-16">
        <div className="absolute inset-0 bg-gradient-glow opacity-30" />
        <div className="container mx-auto px-4 relative">
          <div className="max-w-4xl mx-auto text-center animate-fade-in">
            <div className="inline-flex items-center gap-2 bg-secondary/50 px-4 py-2 rounded-full mb-6 backdrop-blur">
              <CalendarDays className="h-4 w-4 text-primary animate-glow-pulse" />
              <span className="text-sm font-semibold text-foreground">Special Events</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-foreground">
              Upcoming
              <span className="block bg-gradient-primary bg-clip-text text-transparent mt-2">
                Seasonal Offers
              </span>
            </h1>
            
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              Exclusive deals on mobiles, laptops, and electronics for Christmas and New Year celebrations!
            </p>
          </div>
        </div>
      </section>

      {/* Christmas Offers */}
      <section className="container mx-auto px-4 py-12">
        <div className="flex items-center gap-3 mb-8">
          <Gift className="h-8 w-8 text-primary" />
          <h2 className="text-3xl font-bold text-foreground">Christmas Special Offers</h2>
          <Badge variant="secondary" className="ml-auto">Ends Dec 31</Badge>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {christmasOffers.map((offer) => {
            const Icon = offer.icon;
            return (
              <Card key={offer.id} className="bg-card border-border shadow-card hover:shadow-glow transition-all duration-300 hover:scale-105">
                <CardHeader>
                  <div className="w-16 h-16 bg-gradient-primary rounded-lg flex items-center justify-center mb-4">
                    <Icon className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-xl text-foreground">{offer.name}</CardTitle>
                  <Badge variant="outline" className="w-fit">{offer.category}</Badge>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-primary">${offer.offerPrice}</span>
                    <span className="text-lg text-muted-foreground line-through">${offer.originalPrice}</span>
                  </div>
                  <Badge className="bg-gradient-primary">{offer.discount}% OFF</Badge>
                  <p className="text-sm text-muted-foreground">
                    Only {offer.stock} items left in stock!
                  </p>
                  <Button className="w-full bg-gradient-primary hover:opacity-90">
                    View Details
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* New Year Offers */}
        <div className="flex items-center gap-3 mb-8">
          <Gift className="h-8 w-8 text-primary" />
          <h2 className="text-3xl font-bold text-foreground">New Year Mega Sale</h2>
          <Badge variant="secondary" className="ml-auto">Starts Jan 1</Badge>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {newYearOffers.map((offer) => {
            const Icon = offer.icon;
            return (
              <Card key={offer.id} className="bg-card border-border shadow-card hover:shadow-glow transition-all duration-300 hover:scale-105">
                <CardHeader>
                  <div className="w-16 h-16 bg-gradient-primary rounded-lg flex items-center justify-center mb-4">
                    <Icon className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-xl text-foreground">{offer.name}</CardTitle>
                  <Badge variant="outline" className="w-fit">{offer.category}</Badge>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-primary">${offer.offerPrice}</span>
                    <span className="text-lg text-muted-foreground line-through">${offer.originalPrice}</span>
                  </div>
                  <Badge className="bg-gradient-primary">{offer.discount}% OFF</Badge>
                  <p className="text-sm text-muted-foreground">
                    Only {offer.stock} items left in stock!
                  </p>
                  <Button className="w-full bg-gradient-primary hover:opacity-90">
                    View Details
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>
    </div>
  );
};

export default Events;
