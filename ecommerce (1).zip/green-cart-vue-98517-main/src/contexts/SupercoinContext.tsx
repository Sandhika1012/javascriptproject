import { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface SupercoinContextType {
  balance: number;
  addCoins: (amount: number) => void;
  useCoins: (amount: number) => boolean;
  getDiscountAmount: (totalPrice: number) => number;
}

const SupercoinContext = createContext<SupercoinContextType | undefined>(undefined);

const SUPERCOIN_KEY = 'supercoin_balance';
const COIN_VALUE = 0.1; // Each coin = $0.10 discount

export const SupercoinProvider = ({ children }: { children: ReactNode }) => {
  const [balance, setBalance] = useState<number>(() => {
    const stored = localStorage.getItem(SUPERCOIN_KEY);
    return stored ? parseInt(stored) : 100; // Start with 100 free coins
  });

  useEffect(() => {
    localStorage.setItem(SUPERCOIN_KEY, balance.toString());
  }, [balance]);

  const addCoins = (amount: number) => {
    setBalance(prev => prev + amount);
  };

  const useCoins = (amount: number): boolean => {
    if (balance >= amount) {
      setBalance(prev => prev - amount);
      return true;
    }
    return false;
  };

  const getDiscountAmount = (totalPrice: number): number => {
    // Maximum 50% discount or all available coins
    const maxCoinsForDiscount = Math.floor(totalPrice / COIN_VALUE);
    const coinsToUse = Math.min(balance, maxCoinsForDiscount, Math.floor(maxCoinsForDiscount * 0.5));
    return coinsToUse * COIN_VALUE;
  };

  return (
    <SupercoinContext.Provider value={{ balance, addCoins, useCoins, getDiscountAmount }}>
      {children}
    </SupercoinContext.Provider>
  );
};

export const useSupercoins = () => {
  const context = useContext(SupercoinContext);
  if (!context) {
    throw new Error("useSupercoins must be used within SupercoinProvider");
  }
  return context;
};
