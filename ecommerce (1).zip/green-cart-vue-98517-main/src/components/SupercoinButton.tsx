import { Coins } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSupercoins } from "@/contexts/SupercoinContext";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export const SupercoinButton = () => {
  const { balance, getDiscountAmount } = useSupercoins();

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button 
          variant="default" 
          className="gap-2 shadow-[0_2px_8px_rgba(255,153,0,0.3)] hover:shadow-[0_4px_12px_rgba(255,153,0,0.4)]"
        >
          <Coins className="h-5 w-5 animate-glow-pulse" />
          <span className="font-bold">{balance}</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Coins className="h-6 w-6 text-primary" />
            Your Supercoins
          </DialogTitle>
          <DialogDescription>
            Use Supercoins to get instant discounts on your purchases!
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="bg-gradient-glow p-6 rounded-lg text-center">
            <div className="text-5xl font-bold bg-gradient-primary bg-clip-text text-transparent mb-2">
              {balance}
            </div>
            <p className="text-sm text-muted-foreground">Available Supercoins</p>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
              <span className="text-sm font-medium">Coin Value</span>
              <span className="text-sm text-primary font-bold">$0.10 each</span>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
              <span className="text-sm font-medium">Max Discount</span>
              <span className="text-sm text-primary font-bold">Up to 50%</span>
            </div>
          </div>

          <div className="border-t pt-4">
            <h4 className="font-semibold text-sm mb-2">How to earn more coins:</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Complete purchases (10% cashback)</li>
              <li>• Daily login bonus</li>
              <li>• Refer friends</li>
              <li>• Special promotions</li>
            </ul>
          </div>

          <p className="text-xs text-muted-foreground text-center">
            Supercoins are automatically applied at checkout for maximum savings!
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};
