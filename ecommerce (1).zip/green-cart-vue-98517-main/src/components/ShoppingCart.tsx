import { CartItem, updateCartQuantity, removeFromCart, getCartTotal } from "@/lib/storage";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Minus, Plus, Trash2, ShoppingBag, Coins } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { useSupercoins } from "@/contexts/SupercoinContext";
import { useState } from "react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

interface ShoppingCartProps {
  cart: CartItem[];
  onUpdate: () => void;
}

export const ShoppingCart = ({ cart, onUpdate }: ShoppingCartProps) => {
  const total = getCartTotal();
  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const { balance, getDiscountAmount } = useSupercoins();
  const [useCoins, setUseCoins] = useState(true);
  
  const discount = useCoins ? getDiscountAmount(total) : 0;
  const finalTotal = total - discount;
  const coinsUsed = Math.floor(discount / 0.1);

  const handleQuantityChange = (productId: string, newQuantity: number) => {
    updateCartQuantity(productId, newQuantity);
    onUpdate();
  };

  const handleRemove = (productId: string) => {
    removeFromCart(productId);
    onUpdate();
  };

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline" size="icon" className="relative border-primary hover:bg-secondary">
          <ShoppingBag className="h-5 w-5 text-primary" />
          {itemCount > 0 && (
            <Badge className="absolute -top-2 -right-2 h-6 w-6 flex items-center justify-center p-0 bg-gradient-primary">
              {itemCount}
            </Badge>
          )}
        </Button>
      </SheetTrigger>
      
      <SheetContent className="w-full sm:max-w-lg bg-background border-border">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2 text-foreground">
            <ShoppingBag className="h-5 w-5 text-primary" />
            Shopping Cart ({itemCount} items)
          </SheetTitle>
        </SheetHeader>
        
        <div className="flex flex-col h-full pt-6">
          <div className="flex-1 overflow-y-auto space-y-4 pr-2">
            {cart.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                <ShoppingBag className="h-16 w-16 mb-4 opacity-50" />
                <p>Your cart is empty</p>
              </div>
            ) : (
              cart.map((item) => (
                <Card key={item.id} className="bg-card border-border shadow-card">
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      <img
                        src={item.imageUrl}
                        alt={item.name}
                        className="w-20 h-20 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <h4 className="font-semibold text-foreground mb-1">{item.name}</h4>
                        <p className="text-primary font-bold mb-2">${item.price.toFixed(2)}</p>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 border-primary"
                            onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="w-12 text-center font-semibold text-foreground">
                            {item.quantity}
                          </span>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 border-primary"
                            onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                            disabled={item.quantity >= item.stock}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 ml-auto text-destructive hover:bg-destructive/10"
                            onClick={() => handleRemove(item.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
          
          {cart.length > 0 && (
            <Card className="mt-4 bg-card border-primary shadow-glow">
              <CardHeader className="space-y-4">
                {balance > 0 && (
                  <div className="flex items-center justify-between p-3 bg-gradient-glow rounded-lg">
                    <div className="flex items-center gap-2">
                      <Coins className="h-5 w-5 text-primary" />
                      <Label htmlFor="use-coins" className="text-sm font-medium cursor-pointer">
                        Use Supercoins ({balance} available)
                      </Label>
                    </div>
                    <Switch 
                      id="use-coins"
                      checked={useCoins} 
                      onCheckedChange={setUseCoins}
                    />
                  </div>
                )}
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span className="text-foreground font-medium">${total.toFixed(2)}</span>
                  </div>
                  
                  {useCoins && discount > 0 && (
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-primary flex items-center gap-1">
                        <Coins className="h-4 w-4" />
                        Supercoin Discount (-{coinsUsed} coins)
                      </span>
                      <span className="text-primary font-bold">-${discount.toFixed(2)}</span>
                    </div>
                  )}
                  
                  <div className="border-t pt-2">
                    <CardTitle className="flex justify-between items-center">
                      <span className="text-foreground">Final Total</span>
                      <span className="text-primary text-2xl">${finalTotal.toFixed(2)}</span>
                    </CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardFooter>
                <Button className="w-full bg-gradient-primary hover:opacity-90 transition-opacity">
                  Checkout {useCoins && discount > 0 && `(Save $${discount.toFixed(2)})`}
                </Button>
              </CardFooter>
            </Card>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
};
